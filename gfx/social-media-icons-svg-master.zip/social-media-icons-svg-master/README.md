## HTML template with SVG icons for social media.

The social.html file includes 4 SVG code icons
- Facebook
- Instagram
- Twitter
- Youtube

You can paint them and add CSS hover state using the CSS Fill property.

Example from CSS-Tricks website https://css-tricks.com/almanac/properties/f/fill/

If you open the social.html file on a browser, you'll see the 4 icons like this:

![alt text](https://raw.githubusercontent.com/juulio/social-media-icons-svg/master/social-icons.png "Social Icons")
